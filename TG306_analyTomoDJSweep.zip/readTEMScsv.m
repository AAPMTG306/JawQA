function [profdata, channelno]=readTEMScsv(fname)
% readTEMScsv reads the csv file created by Tomotherapy TEMS during the
% Dynamic Jaw sweep test.  You can modify it to read other scans.
% Currently, it assumes that you only connecting to one ion chamber.
% Created by Quan Chen, 9/1/2019
% Email: quanchen@gmail.com 

if(~exist(fname, 'file'))
    return ;
end


%read header for the normalization value
fp=fopen(fname, 'r');
j=1;

for i=1:100
    txt=fgetl(fp);
    if(isempty(txt)) continue; end
    key=textscan(txt, '%s');
    % reading lines till the title
    if (strcmp(key{1}{1}, '*abs'))
        break;
    end

end

val=textscan(fp, '%f%f%f%f%f%f%f%f%f%f%f%f%*[^\n]', 'Delimiter', ',', 'TreatAsEmpty', '-,');
fclose(fp);
profdata.t=val{1};
for i=5:12
    if(~isnan(val{i}))
        profdata.y=val{i};
        channelno=i-4;
        break;
    end
end

