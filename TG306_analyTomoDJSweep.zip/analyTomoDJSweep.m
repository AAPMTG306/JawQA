function [result]= analyTomoDJSweep(incsv, reportcsv)
% analyTomoDJSweep analyze the csv file (incsv) created by Tomotherapy 
% TEMS during Dynamic Jaw sweep test.  The result is saved to reportcsv
% In addition, two plots are created in PNG format.  Note that it will
% overwrite the file with the same name.
% V1.0 Created by Quan Chen, 9/1/2019
% Email: quanchen@gmail.com 
% Revision History
% V1.1 with bug fixes suggested by Simon Chan @ Queen Elizabeth Hospital, Hong Kong  11/11/2021


result=[];
if  nargin<1
    [fname, path] = uigetfile('*.csv', 'Select Tomo dynamic jaw sweep csv file');
    incsv=[path, '/', fname];
end
[profdata, channelno]=readTEMScsv(incsv);
% keep section that contains monotonic increasing t
if(channelno~=8)
    disp('Error! Channel 8 should be used for Jaw Sweep data acquisition!');
    return;
end
ind2=find(diff(profdata.t)<0,1,'first');
if(~isempty(ind2))
    profdata.t=profdata.t(1:ind2);
    profdata.y=profdata.y(1:ind2);
end

dt1=mean(diff(profdata.t)); % approximate delta t for estimate the locations.
maxytemp=max(profdata.y);
maxy=mean(profdata.y(profdata.y>maxytemp*0.98));

%maxy=mean([median(profdata.y(ceil((maxyt(1)-maxyrange)/dt1):ceil((maxyt(1)+maxyrange)/dt1))), ...
%           median(profdata.y(ceil((maxyt(2)-maxyrange)/dt1):ceil((maxyt(2)+maxyrange)/dt1)))]);
profdata.y=profdata.y/maxy*100;
numpts=numel(profdata.t);
% rough search region

%initialguess of the start ramp
indtemp=find(profdata.y>95);
diffind=diff(indtemp);

strtspind(1)=indtemp(find(diffind>1, 1, 'first'));
strtspind(2)=strtspind(1)+ceil(1.8e4/dt1);
% locate 90, 10 region for the start ramp, no interpolation
%strtspind=tempind(1)+[find(profdata.y(tempind(1):tempind(2))>60,1, 'last'), find(profdata.y(tempind(1):tempind(2))>40,1, 'last')];
% rough search region

% locate 90, 10 region for the end ramp
endspind(2)=indtemp(find(diffind>1,1, 'last')+1);
endspind(1)=endspind(2)-ceil(1.8e4/dt1);
%endspind=tempind(1)+[find(profdata.y(tempind(1):tempind(2))>40,1), find(profdata.y(tempind(1):tempind(2))>60,1)];
% use interpolation to get accurate time
strt50t=interp1(profdata.y(strtspind(1):strtspind(2)), profdata.t(strtspind(1):strtspind(2)), 50);
end50t=interp1(profdata.y(endspind(1):endspind(2)), profdata.t(endspind(1):endspind(2)), 50);
duration1=end50t-strt50t;

%relative to the 50% start ramp.
tempt=[1.95e4, 2.35e4];
tempidx=round(interp1(profdata.t, 1:numpts,strt50t+tempt));
fr1t=interp1(profdata.y(tempidx(1):tempidx(2)), profdata.t(tempidx(1):tempidx(2)), [20, 50, 80],'linear','extrap');
fr1dur=fr1t(3)-fr1t(1); % fastrise 1 20-80

tempt=[2.55e4, 2.95e4];
tempidx=round(interp1(profdata.t, 1:numpts,strt50t+tempt));
ff1t=interp1(profdata.y(tempidx(1):tempidx(2)), profdata.t(tempidx(1):tempidx(2)), [20, 50, 80],'linear','extrap');
ff1dur=ff1t(1)-ff1t(3); % fastfall 1 20-80
fastp1pos=mean([fr1t(2), ff1t(2)]);

tempt=[49.95e4, 50.35e4];
tempidx=round(interp1(profdata.t, 1:numpts,strt50t+tempt));
fr2t=interp1(profdata.y(tempidx(1):tempidx(2)), profdata.t(tempidx(1):tempidx(2)), [20, 50, 80],'linear','extrap');
fr2dur=fr2t(3)-fr2t(1); % fastrise 1 20-80

tempt=[50.55e4, 50.95e4];
tempidx=round(interp1(profdata.t, 1:numpts,strt50t+tempt));
ff2t=interp1(profdata.y(tempidx(1):tempidx(2)), profdata.t(tempidx(1):tempidx(2)), [20, 50, 80],'linear','extrap');
ff2dur=ff2t(1)-ff2t(3); % fastfall 1 20-80
fastp2pos=mean([fr2t(2), ff2t(2)]);

result.timelag=fastp2pos-fastp1pos;
result.fastdur=[mean([fr1dur, fr2dur]), mean([ff1dur, ff2dur])];
result.fastconsistency=[abs(fr1dur/fr2dur-1)*100, abs(ff1dur/ff2dur-1)*100];

j7tstart=strt50t+10.3e4+(0:8)*0.5e4;
j7ind=round(interp1(profdata.t, 1:numpts,j7tstart));
j7dur=5;
j7dis.pos=[-17.5, -14, -11, -6, 0, 6, 11, 14, 17.5];
disy(length(j7tstart))=0;
for i=1:length(j7tstart)
    disy(i)=median(profdata.y(j7ind(i):(j7ind(i)+j7dur)));
end
j7dis.y=disy;
result.j7dis=j7dis;
ts=fr1t(2)+(300-42)*1e3;
te=fr1t(2)+(320-42)*1e3;
tempidx=round(interp1(profdata.t, 1:numpts,[ts,te]));
inds=tempidx(1); %approx ind
inde=tempidx(2); %approx ind
ps=mean([-18, -25]);  % mm
pe=mean([18, 25]);    % mm
j7con.pos=((profdata.t(inds:inde)-fr1t(2))/1e3-(300-42))/20*(pe-ps)+ps;
j7con.y=profdata.y(inds:inde);
result.j7con=j7con;
conty=interp1(j7con.pos, j7con.y, j7dis.pos);
diffy=conty-disy;
result.diffy=diffy;
sweeplen=length(j7con.y);

%first 2 points and last 2 points at the largest slope.  So use that to
%compute distance (time) to agreement
%Assume the first 25% and last 25% of the continuous sweep is monotonic
shift(1:2)=interp1(j7con.y(1:round(sweeplen/4)), j7con.pos(1:round(sweeplen/4)), j7dis.y(1:2), 'linear', 'extrap')-j7dis.pos(1:2);
shift(3:4)=interp1(j7con.y((end-round(sweeplen/4)):end), j7con.pos((end-round(sweeplen/4)):end), j7dis.y((end-1):end), 'linear', 'extrap')-j7dis.pos((end-1):end);
result.meanshiftmm=mean(shift);
result.meanshiftms=mean(shift)/(pe-ps)*(profdata.t(inde)-profdata.t(inds));

j7conshift.pos=((profdata.t(inds:inde)-fr1t(2))/1e3-(300-42))/20*(pe-ps)+ps-mean(shift);
j7conshift.y=profdata.y(inds:inde);
result.j7conshift=j7conshift;
conty=interp1(j7conshift.pos, j7conshift.y, j7dis.pos);
diffy=conty-disy;

result.newdiffy=diffy;


% BackJaw 
%relative to the 50% start ramp.
tempt=[35.1e4, 36.9e4];
tempidx=round(interp1(profdata.t, 1:numpts,strt50t+tempt));
BJ1t=interp1(profdata.y(tempidx(1):tempidx(2)), profdata.t(tempidx(1):tempidx(2)), [20, 50, 80],'linear','extrap');
bjo1dur=BJ1t(3)-BJ1t(1); % Back jaw open 20-80

tempt=[37.6e4, 39.4e4];
tempidx=round(interp1(profdata.t, 1:numpts,strt50t+tempt));
BJ1t=interp1(profdata.y(tempidx(1):tempidx(2)), profdata.t(tempidx(1):tempidx(2)), [20, 50, 80],'linear','extrap');
bjc1dur=BJ1t(1)-BJ1t(3); % Back Jaw close 20-80

% front Jaw sweep
tempt=[41.07e4, 42.87e4];
tempidx=round(interp1(profdata.t, 1:numpts,strt50t+tempt));
FJ2t=interp1(profdata.y(tempidx(1):tempidx(2)), profdata.t(tempidx(1):tempidx(2)), [20, 50, 80],'linear','extrap');
fjo1dur=FJ2t(3)-FJ2t(1); % Front Jaw open 20-80

tempt=[43.57e4, 45.37e4];
tempidx=round(interp1(profdata.t, 1:numpts,strt50t+tempt));
FJ2t=interp1(profdata.y(tempidx(1):tempidx(2)), profdata.t(tempidx(1):tempidx(2)), [20, 50, 80],'linear','extrap');
fjc1dur=FJ2t(1)-FJ2t(3); % Front Jaw close 20-80


result.timelag=fastp2pos-fastp1pos-480000;
result.fastdur=[mean([fr1dur, fr2dur]), mean([ff1dur, ff2dur])];
result.BJ=[bjo1dur, bjc1dur];
result.FJ=[fjo1dur, fjc1dur];
result.fastconsistency=[abs(fr1dur/fr2dur-1)*100, abs(ff1dur/ff2dur-1)*100];



% create report
if  nargin<2
    reportcsv=[incsv(1:end-4), '_REPORT.csv'];
end
fp=fopen(reportcsv, 'w');
fprintf(fp, 'Tomo Dynamic Jaw Sweep Analysis Report for %s\n', incsv);
fprintf(fp, '(Created %s)\n', datestr(datetime('now')));
fprintf(fp, 'Time Skew:, %8.3f ,(Second), , , Note: Tolerance < 0.1 s\n', double(result.timelag)/1000.0);
fprintf(fp, 'Elapsed time for Back Jaw Opening from 20%% to 80%% :, %8.3f, (ms), , , Note: difference with reference < 2%% \n', result.BJ(1));
fprintf(fp, 'Elapsed time for Back Jaw Closing from 80%% to 20%% :, %8.3f, (ms), , , Note: difference with reference < 2%% \n', result.BJ(2));
fprintf(fp, 'Elapsed time for Front Jaw Opening from 20%% to 80%% :, %8.3f, (ms), , , Note: difference with reference < 2%% \n', result.FJ(1));
fprintf(fp, 'Elapsed time for Front Jaw Closing from 80%% to 20%% :, %8.3f, (ms), , , Note: difference with reference < 2%% \n', result.FJ(2));

fprintf(fp, 'Elapsed time for Both Jaw Opening from 20%% to 80%% :, %8.3f, (ms), , , Note: difference with reference < 2%% \n', result.fastdur(1));
fprintf(fp, 'Elapsed time for Both Jaw Closing from 80%% to 20%% :, %8.3f, (ms), , , Note: difference with reference < 2%% \n', result.fastdur(2));
fprintf(fp, 'Max %% Difference between discrete and continuous sweep (J7) :, %8.4f, (%%), , , Note: tolerance < 1%% \n', max(abs(result.newdiffy))/max(j7conshift.y)*100);
fprintf(fp, 'Extra Shift applied to align discrete and continuous profiles:, %8.4f, (ms), , , Note: The shift could be influenced by outliers.  If the discrepancy for above line exceed 1%% check the plot created as well as the raw data listed \n', result.meanshiftms);

fprintf(fp, '\n\n\n\n Jaw Sweep data:\n');
fprintf(fp, '1.  raw data\n');
fprintf(fp, ',1.1.  Raw Continuous sweep\n'); 
fprintf(fp, ',pos, rel signal\n');
fprintf(fp, ', %f, %f\n', [result.j7con.pos'; result.j7con.y']);
fprintf(fp, '\n\n,1.2 Shifted continuous data: \n');
fprintf(fp, ',pos, rel signal\n');
fprintf(fp, ', %f, %f\n', [result.j7conshift.pos'; result.j7conshift.y']);
fprintf(fp, '\n\n,1.3.  Discrete sweep\n'); 
fprintf(fp, ',pos, rel signal, diffwRawCont, diffwShiftCont\n');
fprintf(fp, ', %f, %f, %f,%f\n', [result.j7dis.pos; result.j7dis.y; result.diffy; result.newdiffy]);
fclose(fp);
figure, plot(result.j7dis.pos, result.j7dis.y, 'ko');
xlabel('Position (mm)');
ylabel('Rel. Signal');
hold on,
plot(result.j7con.pos, result.j7con.y, 'b-');
grid on
title(sprintf('J7 Jaw Sweep Raw comparison: max diff %4.3f %%', max(abs(result.diffy))/max(j7conshift.y)*100));
legend('J7 Discrete', 'J7 Contin');
saveas(gcf, 'J7SweepRawComp', 'png');
figure, plot(result.j7dis.pos, result.j7dis.y, 'ko');
hold on,
plot(result.j7conshift.pos, result.j7conshift.y, 'b-');
xlabel('Position (mm)');
ylabel('Rel. Signal');
grid on
title(sprintf('J7 Jaw Sweep shifted %5.1f ms: max diff %4.3f %%', result.meanshiftms, max(abs(result.newdiffy))/max(j7conshift.y)*100));
legend('J7 Discrete', 'J7 Contin');
saveas(gcf, 'J7SweepShiftedComp', 'png');


end